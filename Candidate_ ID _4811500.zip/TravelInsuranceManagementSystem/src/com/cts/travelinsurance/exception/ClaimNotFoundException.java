package com.cts.travelinsurance.exception;

public class ClaimNotFoundException extends Exception {
    public ClaimNotFoundException(String message) {
        super(message);
    }
}

