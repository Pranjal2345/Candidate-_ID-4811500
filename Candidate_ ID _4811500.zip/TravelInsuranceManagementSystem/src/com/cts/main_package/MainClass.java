 
package com.cts.main_package;
import com.cts.travelinsurance.dao.PolicyDAO;
import com.cts.travelinsurance.dao.TravelerDAO;
import com.cts.travelinsurance.dao.ClaimDAO;
import com.cts.travelinsurance.dao.PolicyDAOImpl;
import com.cts.travelinsurance.dao.TravelerDAOImpl;
import com.cts.travelinsurance.dao.ClaimDAOImpl;
import com.cts.travelinsurance.exception.ClaimNotFoundException;
import com.cts.travelinsurance.exception.TravelerNotFoundException;
import com.cts.travelinsurance.model.Policy;
import com.cts.travelinsurance.model.Traveler;
import com.cts.travelinsurance.model.Claim;

import java.util.*;

public class MainClass {
    public static void main(String[] args) throws ClaimNotFoundException {
        PolicyDAO policyDAO = new PolicyDAOImpl();
         
        TravelerDAO travelerDAO = new TravelerDAOImpl();
        ClaimDAO claimDAO = new ClaimDAOImpl();

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("===== Travel Insurance Management System =====");
            System.out.println("1. Policy Management");
            System.out.println("2. Traveler Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    managePolicies(policyDAO, scanner);
                    break;
                case 2:
                    manageTravelers(travelerDAO, scanner);
                    break;
                case 3:
                    manageClaims(claimDAO, scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }


    private static void managePolicies(PolicyDAO policyDAO, Scanner scanner) {
    System.out.println("===== Policy Management =====");
    System.out.println("1. Add a new policy");
    System.out.println("2. View policy details");
    System.out.println("3. Update policy information");
    System.out.println("4. Delete a policy");
    System.out.println("5. List all policies");
    System.out.print("Enter your choice: ");
    int choice = scanner.nextInt();

    switch (choice) {
        case 1:
            System.out.print("Enter Policy Number: ");
            String policyNumber = scanner.next();
            System.out.print("Enter Type: ");
            String type = scanner.next();
            System.out.print("Enter Coverage Amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter Premium Amount: ");
            double premiumAmount = scanner.nextDouble();

            Policy newPolicy = new Policy(policyNumber, type, coverageAmount, premiumAmount);
            int policyId = policyDAO.addPolicy(newPolicy);
            System.out.println("Policy added successfully! Policy ID: " + policyId);
            break;

        case 2:
            System.out.print("Enter Policy ID: ");
            policyId = scanner.nextInt();
            Policy policy = policyDAO.getPolicyById(policyId);
            if (policy != null) {
                System.out.println("Policy ID: " + policy.getPolicyId());
                System.out.println("Policy Number: " + policy.getPolicyNumber());
                System.out.println("Type: " + policy.getType());
                System.out.println("Coverage Amount: " + policy.getCoverageAmount());
                System.out.println("Premium Amount: " + policy.getPremiumAmount());
            } else {
                System.out.println("Policy not found!");
            }
            break;

        case 3:
            System.out.print("Enter Policy ID to update: ");
            policyId = scanner.nextInt();
            policy = policyDAO.getPolicyById(policyId);
            if (policy != null) {
                System.out.print("Enter new Coverage Amount: ");
                coverageAmount = scanner.nextDouble();
                System.out.print("Enter new Premium Amount: ");
                premiumAmount = scanner.nextDouble();

                policy.setCoverageAmount(coverageAmount);
                policy.setPremiumAmount(premiumAmount);

                policyDAO.updatePolicy(policy);
                System.out.println("Policy updated successfully!");
            } else {
                System.out.println("Policy not found!");
            }
            break;

        case 4:
            System.out.print("Enter Policy ID to delete: ");
            policyId = scanner.nextInt();
            policyDAO.deletePolicy(policyId);
            System.out.println("Policy deleted successfully!");
            break;

        case 5:
            List<Policy> policies = policyDAO.getAllPolicies();
            if (policies.isEmpty()) {
                System.out.println("No policies found.");
            } else {
                for (Policy p : policies) {
                    System.out.println("Policy ID: " + p.getPolicyId() +
                                       ", Policy Number: " + p.getPolicyNumber() +
                                       ", Type: " + p.getType() +
                                       ", Coverage Amount: " + p.getCoverageAmount() +
                                       ", Premium Amount: " + p.getPremiumAmount());
                }
            }
            break;

        default:
            System.out.println("Invalid choice!");
    }
}
   
    
    private static void manageTravelers(TravelerDAO travelerDAO, Scanner scanner) {
    System.out.println("===== Traveler Management =====");
    System.out.println("1. Register a new traveler");
    System.out.println("2. View traveler details");
    System.out.println("3. Update traveler information");
    System.out.println("4. Delete a traveler");
    System.out.println("5. List all travelers");
    System.out.print("Enter your choice: ");
    int choice = scanner.nextInt();

    try {
        switch (choice) {
            case 1:
                System.out.print("Enter Name: ");
                String name = scanner.next();
                System.out.print("Enter Email: ");
                String email = scanner.next();
                System.out.print("Enter Phone Number: ");
                String phoneNumber = scanner.next();
                System.out.print("Enter Address: ");
                String address = scanner.next();

                Traveler newTraveler = new Traveler(name, email, phoneNumber, address);
                int travelerId = travelerDAO.addTraveler(newTraveler);
                System.out.println("Traveler registered successfully! Traveler ID: " + travelerId);
                break;

            case 2:
                System.out.print("Enter Traveler ID: ");
                int travelerIdToView = scanner.nextInt();
                Traveler traveler = travelerDAO.getTravelerById(travelerIdToView);
                System.out.println("Traveler ID: " + traveler.getTravelerId());
                System.out.println("Name: " + traveler.getName());
                System.out.println("Email: " + traveler.getEmail());
                System.out.println("Phone Number: " + traveler.getPhoneNumber());
                System.out.println("Address: " + traveler.getAddress());
                break;

            case 3:
                System.out.print("Enter Traveler ID to update: ");
                int travelerIdToUpdate = scanner.nextInt();
                Traveler travelerToUpdate = travelerDAO.getTravelerById(travelerIdToUpdate);
                System.out.print("Enter new Email: ");
                String newEmail = scanner.next();
                System.out.print("Enter new Phone Number: ");
                String newPhoneNumber = scanner.next();
                System.out.print("Enter new Address: ");
                String newAddress = scanner.next();

                travelerToUpdate.setEmail(newEmail);
                travelerToUpdate.setPhoneNumber(newPhoneNumber);
                travelerToUpdate.setAddress(newAddress);

                travelerDAO.updateTraveler(travelerToUpdate);
                System.out.println("Traveler updated successfully!");
                break;

            case 4:
                System.out.print("Enter Traveler ID to delete: ");
                int travelerIdToDelete = scanner.nextInt();
                travelerDAO.deleteTraveler(travelerIdToDelete);
                System.out.println("Traveler deleted successfully!");
                break;

            case 5:
                List<Traveler> travelers = travelerDAO.getAllTravelers();
                System.out.println("All Travelers:");
                for (Traveler trvlr : travelers) {
                    System.out.println("Traveler ID: " + trvlr.getTravelerId() +
                            ", Name: " + trvlr.getName() +
                            ", Email: " + trvlr.getEmail() +
                            ", Phone: " + trvlr.getPhoneNumber() +
                            ", Address: " + trvlr.getAddress());
                }
                break;

            default:
                System.out.println("Invalid choice!");
        }
    } catch (TravelerNotFoundException e) {
        System.out.println(e.getMessage());
    }
}


    
    
    
    
    
    

private static void manageClaims(ClaimDAO claimDAO, Scanner scanner) throws ClaimNotFoundException {
    System.out.println("===== Claim Management =====");
    System.out.println("1. Submit a new claim");
    System.out.println("2. View claim details");
    System.out.println("3. Update claim information");
    System.out.println("4. Delete a claim");
    System.out.println("5. List all claims");
    System.out.print("Enter your choice: ");
    int choice = scanner.nextInt();

    switch (choice) {
        case 1:
            System.out.print("Enter Policy ID: ");
            int policyId = scanner.nextInt();
            System.out.print("Enter Traveler ID: ");
            int travelerId = scanner.nextInt();
            System.out.print("Enter Claim Date: ");
            String claimDate = scanner.next(); // Assuming date as string for this implementation
            System.out.print("Enter Status (submitted/processed): ");
            String status = scanner.next();

            Claim newClaim = new Claim(policyId, travelerId, claimDate, status);
            int claimId = claimDAO.addClaim(newClaim);
            System.out.println("Claim submitted successfully! Claim ID: " + claimId);
            break;

        case 2:
            System.out.print("Enter Claim ID: ");
            claimId = scanner.nextInt();
            Claim claim = claimDAO.getClaimById(claimId);
            if (claim != null) {
                System.out.println("Claim ID: " + claim.getClaimId());
                System.out.println("Policy ID: " + claim.getPolicyId());
                System.out.println("Traveler ID: " + claim.getTravelerId());
                System.out.println("Claim Date: " + claim.getClaimDate());
                System.out.println("Status: " + claim.getStatus());
            } else {
                System.out.println("Claim not found!");
            }
            break;

        case 3:
            System.out.print("Enter Claim ID to update: ");
            claimId = scanner.nextInt();
            claim = claimDAO.getClaimById(claimId);
            if (claim != null) {
                System.out.print("Enter new Claim Date: ");
                claimDate = scanner.next();
                System.out.print("Enter new Status: ");
                status = scanner.next();

                claim.setClaimDate(claimDate);
                claim.setStatus(status);

                claimDAO.updateClaim(claim);
                System.out.println("Claim updated successfully!");
            } else {
                System.out.println("Claim not found!");
            }
            break;

        case 4:
            System.out.print("Enter Claim ID to delete: ");
            claimId = scanner.nextInt();
            claimDAO.deleteClaim(claimId);
            System.out.println("Claim deleted successfully!");
            break;

        case 5:
            List<Claim> claims = claimDAO.getAllClaims();
            System.out.println("All Claims:");
            for (Claim clm : claims) {
                System.out.println("Claim ID: " + clm.getClaimId() + ", Policy ID: " + clm.getPolicyId() +
                        ", Traveler ID: " + clm.getTravelerId() + ", Claim Date: " + clm.getClaimDate() +
                        ", Status: " + clm.getStatus());
            }
            break;

        default:
            System.out.println("Invalid choice!");
    }
}
}