

package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.model.Claim;
import com.cts.travelinsurance.exception.ClaimNotFoundException;

import java.util.List;

public interface ClaimDAO {
    int addClaim(Claim claim);
    Claim getClaimById(int claimId) throws ClaimNotFoundException;
    List<Claim> getAllClaims();
    void updateClaim(Claim claim) throws ClaimNotFoundException;
    void deleteClaim(int claimId) throws ClaimNotFoundException;
}

